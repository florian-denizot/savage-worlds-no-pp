const groupName = "BRSW.powerAction";

export const modifiers = [
{
    id:"POWER_PREPARATION",
    name:"BRSW.powerPreparation",
    button_name:"BRSW.powerPreparation",
    skillMod: "+2",
    selector_type: "item_type", 
    selector_value: "power", 
    group: groupName
}];